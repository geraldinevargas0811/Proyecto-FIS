/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gimnasio.servlet;

import com.gimnasio.modelo.Cliente;
import com.gimnasio.servicio.ClienteServicio;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/VerDatosServlet")
public class VerDatosServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private ClienteServicio clienteServicio;
    
    @Override
    public void init() throws ServletException {
        super.init();
        clienteServicio = new ClienteServicio();
        System.out.println("✅ VerDatosServlet inicializado");
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        // ✅ AGREGAR LOGS
        System.out.println("===========================================");
        System.out.println("📋 VerDatosServlet - Iniciando carga de clientes");
        System.out.println("===========================================");
        
        try {
            List<Cliente> clientes = clienteServicio.obtenerTodosLosClientes();
            
            // ✅ AGREGAR LOGS
            System.out.println("📊 Clientes obtenidos: " + (clientes != null ? clientes.size() : "null"));
            
            if (clientes != null && !clientes.isEmpty()) {
                for (int i = 0; i < clientes.size(); i++) {
                    System.out.println("  " + (i+1) + ". " + clientes.get(i).getNombre());
                }
            }
            
            request.setAttribute("listaClientes", clientes);
            request.setAttribute("totalClientes", clientes != null ? clientes.size() : 0);
            
            System.out.println("✅ Redirigiendo a ver-datos.jsp");
            System.out.println("===========================================");
            
            request.getRequestDispatcher("ver-datos.jsp").forward(request, response);
            
        } catch (Exception e) {
            System.err.println("❌ Error al obtener clientes: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "Error al cargar los datos.");
            request.getRequestDispatcher("ver-datos.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}
