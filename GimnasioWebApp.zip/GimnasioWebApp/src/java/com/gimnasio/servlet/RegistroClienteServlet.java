/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gimnasio.servlet;

import com.gimnasio.modelo.Cliente;
import com.gimnasio.servicio.ClienteServicio;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Servlet que maneja el registro de nuevos clientes.
 * Cumple con el principio de Responsabilidad Única (SRP):
 * Su única responsabilidad es manejar las peticiones HTTP relacionadas con el registro.
 */
@WebServlet("/RegistroClienteServlet")
public class RegistroClienteServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private ClienteServicio clienteServicio;
    
    @Override
    public void init() throws ServletException {
        super.init();
        clienteServicio = new ClienteServicio();
        System.out.println("✅ RegistroClienteServlet inicializado");
    }
    
    /**
     * Maneja peticiones POST del formulario de registro.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Configurar encoding
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        try {
            // 1. Obtener parámetros del formulario
            String nombre = request.getParameter("nombre");
            int edad = Integer.parseInt(request.getParameter("edad"));
            double peso = Double.parseDouble(request.getParameter("peso"));
            double altura = Double.parseDouble(request.getParameter("altura"));
            String proposito = request.getParameter("proposito");
            int diasEntrenamiento = Integer.parseInt(request.getParameter("diasEntrenamiento"));
            
            // 2. Validar datos (validación adicional del lado del servidor)
            if (!validarDatos(nombre, edad, peso, altura, proposito, diasEntrenamiento)) {
                request.setAttribute("error", "Datos inválidos. Por favor verifica la información.");
                request.getRequestDispatcher("index.html").forward(request, response);
                return;
            }
            
            // 3. Crear objeto Cliente
            Cliente cliente = new Cliente(nombre, edad, peso, altura, proposito, diasEntrenamiento);
            
            // 4. Procesar cliente (calcular IMC, generar rutina, guardar)
            boolean exito = clienteServicio.procesarNuevoCliente(cliente);
            
            if (exito) {
                // 5. Guardar cliente en sesión para mostrarlo en la página de rutina
                HttpSession session = request.getSession();
                session.setAttribute("clienteActual", cliente);
                
                System.out.println("✅ Cliente procesado exitosamente: " + nombre);
                
                // 6. Redirigir a página de rutina generada
                response.sendRedirect("rutina-generada.jsp");
                
            } else {
                // Error al procesar
                request.setAttribute("error", "Error al procesar el cliente. Intenta nuevamente.");
                request.getRequestDispatcher("index.html").forward(request, response);
            }
            
        } catch (NumberFormatException e) {
            System.err.println("❌ Error de formato en los datos: " + e.getMessage());
            request.setAttribute("error", "Error en el formato de los datos. Verifica los valores numéricos.");
            request.getRequestDispatcher("index.html").forward(request, response);
            
        } catch (Exception e) {
            System.err.println("❌ Error inesperado: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "Error inesperado. Por favor contacta al administrador.");
            request.getRequestDispatcher("index.html").forward(request, response);
        }
    }
    
    /**
     * Maneja peticiones GET (redirige al formulario).
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.sendRedirect("index.html");
    }
    
    /**
     * Valida los datos recibidos del formulario.
     */
    private boolean validarDatos(String nombre, int edad, double peso, double altura, 
                                  String proposito, int diasEntrenamiento) {
        
        // Validar nombre
        if (nombre == null || nombre.trim().isEmpty() || nombre.length() < 3) {
            return false;
        }
        
        // Validar edad
        if (edad < 15 || edad > 100) {
            return false;
        }
        
        // Validar peso
        if (peso < 30 || peso > 300) {
            return false;
        }
        
        // Validar altura
        if (altura < 1.0 || altura > 2.5) {
            return false;
        }
        
        // Validar propósito
        if (proposito == null || proposito.trim().isEmpty()) {
            return false;
        }
        
        // Validar días
        if (diasEntrenamiento < 1 || diasEntrenamiento > 7) {
            return false;
        }
        
        return true;
    }
}