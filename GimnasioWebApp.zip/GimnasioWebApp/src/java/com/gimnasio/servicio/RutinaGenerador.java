/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gimnasio.servicio;

import com.gimnasio.modelo.DiaEntrenamiento;
import com.gimnasio.modelo.Ejercicio;
import com.gimnasio.modelo.Rutina;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Clase que genera rutinas de entrenamiento personalizadas.
 * Cumple con el principio Open/Closed de SOLID:
 * Puede extenderse para agregar nuevos tipos de rutinas sin modificar el código existente.
 */
public class RutinaGenerador {
    
    private static final Random random = new Random();
    
    /**
     * Genera una rutina completa según el propósito del cliente.
     * 
     * @param proposito Propósito del entrenamiento
     * @return Rutina generada
     */
    public static Rutina generarRutina(String proposito) {
        // Generar número aleatorio de días (2-5)
        int numeroDias = random.nextInt(4) + 2; // 2, 3, 4 o 5 días
        
        Rutina rutina = new Rutina(proposito, numeroDias);
        
        // Obtener los tipos de días según el número de días
        List<String> tiposDias = obtenerTiposDias(numeroDias);
        
        // Generar cada día
        for (int i = 0; i < numeroDias; i++) {
            DiaEntrenamiento dia = generarDia(i + 1, tiposDias.get(i), proposito);
            rutina.agregarDia(dia);
        }
        
        return rutina;
    }
    
    /**
     * Obtiene los tipos de días según el número de días de la rutina.
     */
    private static List<String> obtenerTiposDias(int numeroDias) {
        List<String> tipos = new ArrayList<>();
        
        switch (numeroDias) {
            case 2:
                tipos.add("PARTE SUPERIOR");
                tipos.add("PARTE INFERIOR");
                break;
            case 3:
                tipos.add("PUSH (EMPUJE)");
                tipos.add("PULL (JALÓN)");
                tipos.add("PIERNAS");
                break;
            case 4:
                tipos.add("PARTE SUPERIOR");
                tipos.add("PARTE INFERIOR");
                tipos.add("PUSH (EMPUJE)");
                tipos.add("PULL (JALÓN)");
                break;
            case 5:
                tipos.add("PECHO");
                tipos.add("ESPALDA");
                tipos.add("PIERNAS");
                tipos.add("HOMBROS Y BRAZOS");
                tipos.add("FULLBODY");
                break;
        }
        
        return tipos;
    }
    
    /**
     * Genera un día de entrenamiento específico.
     */
    private static DiaEntrenamiento generarDia(int numeroDia, String tipoDia, String proposito) {
        DiaEntrenamiento dia = new DiaEntrenamiento(numeroDia, tipoDia);
        
        // Obtener ejercicios según el tipo de día
        List<Ejercicio> ejercicios = obtenerEjerciciosPorTipo(tipoDia, proposito);
        
        // Agregar ejercicios al día
        for (Ejercicio ejercicio : ejercicios) {
            dia.agregarEjercicio(ejercicio);
        }
        
        return dia;
    }
    
    /**
     * Obtiene ejercicios según el tipo de día y propósito.
     */
    private static List<Ejercicio> obtenerEjerciciosPorTipo(String tipoDia, String proposito) {
        List<Ejercicio> ejercicios = new ArrayList<>();
        
        // Determinar series y repeticiones según propósito
        int series = obtenerSeries(proposito);
        String repeticiones = obtenerRepeticiones(proposito);
        
        switch (tipoDia) {
            case "PARTE SUPERIOR":
                ejercicios.add(new Ejercicio("Press de Banca", series, repeticiones, "imagenes/ejercicios/press_banca.jpg"));
                ejercicios.add(new Ejercicio("Remo con Barra", series, repeticiones, "imagenes/ejercicios/remo_barra.jpeg"));
                ejercicios.add(new Ejercicio("Press Militar", series, repeticiones, "imagenes/ejercicios/press_militar.jpg"));
                ejercicios.add(new Ejercicio("Dominadas", series, repeticiones, "imagenes/ejercicios/dominadas.png"));
                ejercicios.add(new Ejercicio("Curl de Bíceps", series, repeticiones, "imagenes/ejercicios/curl_biceps.jpeg"));
                ejercicios.add(new Ejercicio("Extensiones de Tríceps", series, repeticiones, "imagenes/ejercicios/extensiones_triceps.jpg"));
                break;
                
            case "PARTE INFERIOR":
                ejercicios.add(new Ejercicio("Sentadillas", series, repeticiones, "imagenes/ejercicios/sentadillas.jpg"));
                ejercicios.add(new Ejercicio("Peso Muerto", series, repeticiones, "imagenes/ejercicios/peso_muerto.jpeg"));
                ejercicios.add(new Ejercicio("Prensa de Piernas", series, repeticiones, "imagenes/ejercicios/prensa_piernas.jpeg"));
                ejercicios.add(new Ejercicio("Zancadas", series, repeticiones, "imagenes/ejercicios/zancadas.jpeg"));
                ejercicios.add(new Ejercicio("Curl Femoral", series, repeticiones, "imagenes/ejercicios/curl_femoral.jpg"));
                ejercicios.add(new Ejercicio("Elevaciones de Pantorrilla", series, repeticiones, "imagenes/ejercicios/elevaciones_pantorrilla.jpeg"));
                break;
                
            case "PUSH (EMPUJE)":
                ejercicios.add(new Ejercicio("Press de Banca Inclinado", series, repeticiones, "imagenes/ejercicios/press_inclinado.jpeg"));
                ejercicios.add(new Ejercicio("Press con Mancuernas", series, repeticiones, "imagenes/ejercicios/press_mancuernas.jpeg"));
                ejercicios.add(new Ejercicio("Aperturas con Mancuernas", series, repeticiones, "imagenes/ejercicios/aperturas.jpeg"));
                ejercicios.add(new Ejercicio("Press Militar", series, repeticiones, "imagenes/ejercicios/press_militar.jpg"));
                ejercicios.add(new Ejercicio("Fondos en Paralelas", series, repeticiones, "imagenes/ejercicios/fondos.jpeg"));
                ejercicios.add(new Ejercicio("Extensiones de Tríceps", series, repeticiones, "imagenes/ejercicios/extensiones_triceps.jpg"));
                break;
                
            case "PULL (JALÓN)":
                ejercicios.add(new Ejercicio("Dominadas", series, repeticiones, "imagenes/ejercicios/dominadas.png"));
                ejercicios.add(new Ejercicio("Remo con Barra", series, repeticiones, "imagenes/ejercicios/remo_barra.jpeg"));
                ejercicios.add(new Ejercicio("Jalón al Pecho", series, repeticiones, "imagenes/ejercicios/jalon_pecho.jpeg"));
                ejercicios.add(new Ejercicio("Remo con Mancuerna", series, repeticiones, "imagenes/ejercicios/remo_mancuerna.jpg"));
                ejercicios.add(new Ejercicio("Curl de Bíceps con Barra", series, repeticiones, "imagenes/ejercicios/curl_barra.jpg"));
                ejercicios.add(new Ejercicio("Curl Martillo", series, repeticiones, "imagenes/ejercicios/curl_martillo.jpeg"));
                break;
                
            case "PIERNAS":
                ejercicios.add(new Ejercicio("Sentadillas", series, repeticiones, "imagenes/ejercicios/sentadillas.jpg"));
                ejercicios.add(new Ejercicio("Peso Muerto Rumano", series, repeticiones, "imagenes/ejercicios/peso_muerto_rumano.jpeg"));
                ejercicios.add(new Ejercicio("Prensa de Piernas", series, repeticiones, "imagenes/ejercicios/prensa_piernas.jpeg"));
                ejercicios.add(new Ejercicio("Extensiones de Cuádriceps", series, repeticiones, "imagenes/ejercicios/extensiones_cuadriceps.jpeg"));
                ejercicios.add(new Ejercicio("Curl Femoral", series, repeticiones, "imagenes/ejercicios/curl_femoral.jpg"));
                ejercicios.add(new Ejercicio("Elevaciones de Pantorrilla", series, repeticiones, "imagenes/ejercicios/elevaciones_pantorrilla.jpeg"));
                break;
                
            case "PECHO":
                ejercicios.add(new Ejercicio("Press de Banca", series, repeticiones, "imagenes/ejercicios/press_banca.jpg"));
                ejercicios.add(new Ejercicio("Press Inclinado", series, repeticiones, "imagenes/ejercicios/press_inclinado.jpeg"));
                ejercicios.add(new Ejercicio("Aperturas con Mancuernas", series, repeticiones, "imagenes/ejercicios/aperturas.jpeg"));
                ejercicios.add(new Ejercicio("Fondos en Paralelas", series, repeticiones, "imagenes/ejercicios/fondos.jpeg"));
                ejercicios.add(new Ejercicio("Cruce de Poleas", series, repeticiones, "imagenes/ejercicios/cruce_poleas.jpeg"));
                break;
                
            case "ESPALDA":
                ejercicios.add(new Ejercicio("Peso Muerto", series, repeticiones, "imagenes/ejercicios/peso_muerto.jpeg"));
                ejercicios.add(new Ejercicio("Dominadas", series, repeticiones, "imagenes/ejercicios/dominadas.png"));
                ejercicios.add(new Ejercicio("Remo con Barra", series, repeticiones, "imagenes/ejercicios/remo_barra.jpeg"));
                ejercicios.add(new Ejercicio("Jalón al Pecho", series, repeticiones, "imagenes/ejercicios/jalon_pecho.jpeg"));
                ejercicios.add(new Ejercicio("Remo con Mancuerna", series, repeticiones, "imagenes/ejercicios/remo_mancuerna.jpg"));
                break;
                
            case "HOMBROS Y BRAZOS":
                ejercicios.add(new Ejercicio("Press Militar", series, repeticiones, "imagenes/ejercicios/press_militar.jpg"));
                ejercicios.add(new Ejercicio("Elevaciones Laterales", series, repeticiones, "imagenes/ejercicios/elevaciones_laterales.jpg"));
                ejercicios.add(new Ejercicio("Elevaciones Frontales", series, repeticiones, "imagenes/ejercicios/elevaciones_frontales.jpeg"));
                ejercicios.add(new Ejercicio("Curl de Bíceps", series, repeticiones, "imagenes/ejercicios/curl_biceps.jpeg"));
                ejercicios.add(new Ejercicio("Extensiones de Tríceps", series, repeticiones, "imagenes/ejercicios/extensiones_triceps.jpg"));
                ejercicios.add(new Ejercicio("Curl Martillo", series, repeticiones, "imagenes/ejercicios/curl_martillo.jpeg"));
                break;
                
            case "FULLBODY":
                ejercicios.add(new Ejercicio("Sentadillas", series, repeticiones, "imagenes/ejercicios/sentadillas.jpg"));
                ejercicios.add(new Ejercicio("Press de Banca", series, repeticiones, "imagenes/ejercicios/press_banca.jpg"));
                ejercicios.add(new Ejercicio("Peso Muerto", series, repeticiones, "imagenes/ejercicios/peso_muerto.jpeg"));
                ejercicios.add(new Ejercicio("Dominadas", series, repeticiones, "imagenes/ejercicios/dominadas.png"));
                ejercicios.add(new Ejercicio("Press Militar", series, repeticiones, "imagenes/ejercicios/press_militar.jpg"));
                ejercicios.add(new Ejercicio("Remo con Barra", series, repeticiones, "imagenes/ejercicios/remo_barra.jpeg"));
                break;
        }
        
        return ejercicios;
    }
    
    /**
     * Determina el número de series según el propósito.
     */
    private static int obtenerSeries(String proposito) {
        switch (proposito) {
            case "volumen":
                return 4; // Más series para hipertrofia
            case "definicion":
                return 3; // Series moderadas con más repeticiones
            case "bajar_peso":
                return 3; // Series moderadas con cardio adicional
            case "mantener":
                return 3; // Series equilibradas
            default:
                return 3;
        }
    }
    
    /**
     * Determina el rango de repeticiones según el propósito.
     */
    private static String obtenerRepeticiones(String proposito) {
        switch (proposito) {
            case "volumen":
                return "6-8"; // Más peso, menos repeticiones (hipertrofia)
            case "definicion":
                return "12-15"; // Menos peso, más repeticiones
            case "bajar_peso":
                return "15-20"; // Alta intensidad, muchas repeticiones
            case "mantener":
                return "8-12"; // Rango equilibrado
            default:
                return "8-12";
        }
    }
}