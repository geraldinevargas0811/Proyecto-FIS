/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gimnasio.servicio;

import com.gimnasio.modelo.Cliente;
import com.gimnasio.modelo.Rutina;
import com.gimnasio.persistencia.ClienteDAO;

import java.util.List;

/**
 * Capa de servicio que maneja la lógica de negocio relacionada con clientes.
 * Cumple con el principio de Responsabilidad Única (SRP):
 * Coordina las operaciones entre el modelo, el cálculo de IMC, la generación de rutinas y la persistencia.
 */
public class ClienteServicio {
    
    private ClienteDAO clienteDAO;
    
    // Constructor
    public ClienteServicio() {
        this.clienteDAO = new ClienteDAO();
    }
    
    /**
     * Procesa un nuevo cliente: calcula IMC, genera rutina y guarda en archivo.
     * 
     * @param cliente Cliente a procesar
     * @return true si se procesó correctamente, false en caso contrario
     */
    public boolean procesarNuevoCliente(Cliente cliente) {
        try {
            // 1. Calcular IMC
            double imc = IMCCalculador.calcularIMC(cliente.getPeso(), cliente.getAltura());
            String clasificacion = IMCCalculador.clasificarIMC(imc);
            
            cliente.setImc(imc);
            cliente.setClasificacionIMC(clasificacion);
            
            // 2. Generar rutina personalizada
            Rutina rutina = RutinaGenerador.generarRutina(cliente.getProposito());
            cliente.setRutina(rutina);
            
            // 3. Guardar en archivo
            return clienteDAO.guardarCliente(cliente);
            
        } catch (Exception e) {
            System.err.println("Error al procesar cliente: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Obtiene todos los clientes registrados.
     * 
     * @return Lista de clientes
     */
    public List<Cliente> obtenerTodosLosClientes() {
        try {
            return clienteDAO.obtenerTodosLosClientes();
        } catch (Exception e) {
            System.err.println("Error al obtener clientes: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Busca un cliente por su ID.
     * 
     * @param id ID del cliente
     * @return Cliente encontrado o null
     */
    public Cliente buscarClientePorId(String id) {
        try {
            List<Cliente> clientes = clienteDAO.obtenerTodosLosClientes();
            for (Cliente cliente : clientes) {
                if (cliente.getId().equals(id)) {
                    return cliente;
                }
            }
            return null;
        } catch (Exception e) {
            System.err.println("Error al buscar cliente: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Obtiene el número total de clientes registrados.
     * 
     * @return Número de clientes
     */
    public int contarClientes() {
        try {
            List<Cliente> clientes = clienteDAO.obtenerTodosLosClientes();
            return clientes != null ? clientes.size() : 0;
        } catch (Exception e) {
            System.err.println("Error al contar clientes: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }
}