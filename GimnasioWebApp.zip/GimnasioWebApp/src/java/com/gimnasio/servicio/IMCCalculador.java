/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gimnasio.servicio;

/**
 * Clase utilitaria para calcular el IMC (Índice de Masa Corporal).
 * Cumple con el principio de Responsabilidad Única (SRP):
 * Su única responsabilidad es calcular y clasificar el IMC.
 */
public class IMCCalculador {
    
    /**
     * Calcula el IMC basado en peso y altura.
     * Fórmula: IMC = peso(kg) / altura(m)²
     * 
     * @param peso Peso en kilogramos
     * @param altura Altura en metros
     * @return Valor del IMC
     */
    public static double calcularIMC(double peso, double altura) {
        if (altura <= 0 || peso <= 0) {
            throw new IllegalArgumentException("Peso y altura deben ser mayores a 0");
        }
        return peso / (altura * altura);
    }
    
    /**
     * Clasifica el IMC según los estándares de la OMS.
     * 
     * @param imc Valor del IMC
     * @return Clasificación del IMC
     */
    public static String clasificarIMC(double imc) {
        if (imc < 18.5) {
            return "Bajo peso";
        } else if (imc >= 18.5 && imc < 25) {
            return "Normal";
        } else if (imc >= 25 && imc < 30) {
            return "Sobrepeso";
        } else {
            return "Obesidad";
        }
    }
    
    /**
     * Calcula y clasifica el IMC en un solo método.
     * 
     * @param peso Peso en kilogramos
     * @param altura Altura en metros
     * @return Array con [IMC, Clasificación]
     */
    public static String[] calcularYClasificar(double peso, double altura) {
        double imc = calcularIMC(peso, altura);
        String clasificacion = clasificarIMC(imc);
        return new String[] { String.format("%.2f", imc), clasificacion };
    }
}