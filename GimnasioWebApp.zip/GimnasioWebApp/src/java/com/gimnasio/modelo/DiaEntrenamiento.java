/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gimnasio.modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase que representa un Día de entrenamiento dentro de una rutina.
 * Cumple con el principio de Responsabilidad Única (SRP):
 * Gestiona únicamente la información de un día específico.
 */
public class DiaEntrenamiento implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    // Atributos
    private int numeroDia;
    private String nombreDia; // Ej: "PARTE SUPERIOR", "PARTE INFERIOR", etc.
    private List<Ejercicio> ejercicios;
    
    // Constructor vacío
    public DiaEntrenamiento() {
        this.ejercicios = new ArrayList<>();
    }
    
    // Constructor con parámetros
    public DiaEntrenamiento(int numeroDia, String nombreDia) {
        this();
        this.numeroDia = numeroDia;
        this.nombreDia = nombreDia;
    }
    
    // Método para agregar un ejercicio
    public void agregarEjercicio(Ejercicio ejercicio) {
        ejercicios.add(ejercicio);
    }
    
    // Getters y Setters
    public int getNumeroDia() {
        return numeroDia;
    }
    
    public void setNumeroDia(int numeroDia) {
        this.numeroDia = numeroDia;
    }
    
    public String getNombreDia() {
        return nombreDia;
    }
    
    public void setNombreDia(String nombreDia) {
        this.nombreDia = nombreDia;
    }
    
    public List<Ejercicio> getEjercicios() {
        return ejercicios;
    }
    
    public void setEjercicios(List<Ejercicio> ejercicios) {
        this.ejercicios = ejercicios;
    }
    
    // Método toString para representación en texto
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Día ").append(numeroDia).append(": ").append(nombreDia).append("\n");
        
        for (int i = 0; i < ejercicios.size(); i++) {
            sb.append("  ").append(i + 1).append(". ");
            sb.append(ejercicios.get(i).toString());
            sb.append("\n");
        }
        
        return sb.toString();
    }
}