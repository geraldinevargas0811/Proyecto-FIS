/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gimnasio.modelo;

import java.io.Serializable;

/**
 * Clase que representa un Ejercicio específico.
 * Cumple con el principio de Responsabilidad Única (SRP):
 * Solo gestiona la información de un ejercicio.
 */
public class Ejercicio implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    // Atributos
    private String nombre;
    private int series;
    private String repeticiones; // Puede ser "8-10", "12-15", "al fallo", etc.
    private String imagenUrl; // Ruta relativa de la imagen
    
    // Constructor vacío
    public Ejercicio() {
    }
    
    // Constructor con parámetros
    public Ejercicio(String nombre, int series, String repeticiones, String imagenUrl) {
        this.nombre = nombre;
        this.series = series;
        this.repeticiones = repeticiones;
        this.imagenUrl = imagenUrl;
    }
    
    // Getters y Setters
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public int getSeries() {
        return series;
    }
    
    public void setSeries(int series) {
        this.series = series;
    }
    
    public String getRepeticiones() {
        return repeticiones;
    }
    
    public void setRepeticiones(String repeticiones) {
        this.repeticiones = repeticiones;
    }
    
    public String getImagenUrl() {
        return imagenUrl;
    }
    
    public void setImagenUrl(String imagenUrl) {
        this.imagenUrl = imagenUrl;
    }
    
    // Método para obtener el texto de series y repeticiones formateado
    public String getSeriesYRepeticiones() {
        return series + " series x " + repeticiones + " repeticiones";
    }
    
    // Método toString para representación en texto
    @Override
    public String toString() {
        return nombre + " - " + getSeriesYRepeticiones();
    }
}