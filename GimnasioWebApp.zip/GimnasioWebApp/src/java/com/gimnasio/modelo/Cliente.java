/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gimnasio.modelo;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Clase que representa un Cliente del gimnasio.
 * Cumple con el principio de Responsabilidad Única (SRP) de SOLID:
 * Su única responsabilidad es representar los datos de un cliente.
 */
public class Cliente implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    // Atributos
    private String id;
    private String nombre;
    private int edad;
    private double peso;
    private double altura;
    private double imc;
    private String clasificacionIMC;
    private String proposito;
    private int diasEntrenamiento;
    private Rutina rutina;
    private LocalDate fechaRegistro;
    
    // Constructor vacío
    public Cliente() {
        this.fechaRegistro = LocalDate.now();
        this.id = generarId();
    }
    
    // Constructor con parámetros
    public Cliente(String nombre, int edad, double peso, double altura, 
                   String proposito, int diasEntrenamiento) {
        this();
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        this.altura = altura;
        this.proposito = proposito;
        this.diasEntrenamiento = diasEntrenamiento;
    }
    
    // Método para generar ID único
    private String generarId() {
        return "CLI" + System.currentTimeMillis();
    }
    
    // Getters y Setters
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public int getEdad() {
        return edad;
    }
    
    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    public double getPeso() {
        return peso;
    }
    
    public void setPeso(double peso) {
        this.peso = peso;
    }
    
    public double getAltura() {
        return altura;
    }
    
    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    public double getImc() {
        return imc;
    }
    
    public void setImc(double imc) {
        this.imc = imc;
    }
    
    public String getClasificacionIMC() {
        return clasificacionIMC;
    }
    
    public void setClasificacionIMC(String clasificacionIMC) {
        this.clasificacionIMC = clasificacionIMC;
    }
    
    public String getProposito() {
        return proposito;
    }
    
    public void setProposito(String proposito) {
        this.proposito = proposito;
    }
    
    public int getDiasEntrenamiento() {
        return diasEntrenamiento;
    }
    
    public void setDiasEntrenamiento(int diasEntrenamiento) {
        this.diasEntrenamiento = diasEntrenamiento;
    }
    
    public Rutina getRutina() {
        return rutina;
    }
    
    public void setRutina(Rutina rutina) {
        this.rutina = rutina;
    }
    
    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }
    
    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }
    
    public String getFechaRegistroFormateada() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return fechaRegistro.format(formatter);
    }
    
    // Método toString para representación en texto
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ID: ").append(id).append("\n");
        sb.append("Nombre: ").append(nombre).append("\n");
        sb.append("Edad: ").append(edad).append(" años\n");
        sb.append("Peso: ").append(peso).append(" kg\n");
        sb.append("Altura: ").append(altura).append(" m\n");
        sb.append("IMC: ").append(String.format("%.2f", imc)).append("\n");
        sb.append("Clasificación IMC: ").append(clasificacionIMC).append("\n");
        sb.append("Propósito: ").append(proposito).append("\n");
        sb.append("Días/semana: ").append(diasEntrenamiento).append("\n");
        sb.append("Fecha Registro: ").append(getFechaRegistroFormateada()).append("\n");
        return sb.toString();
    }
}
