/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gimnasio.modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase que representa una Rutina de entrenamiento.
 * Cumple con el principio Open/Closed de SOLID:
 * Abierta para extensión (se pueden agregar más días), cerrada para modificación.
 */
public class Rutina implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    // Atributos
    private String id;
    private String proposito;
    private int numeroDias;
    private List<DiaEntrenamiento> dias;
    
    // Constructor vacío
    public Rutina() {
        this.dias = new ArrayList<>();
        this.id = generarId();
    }
    
    // Constructor con parámetros
    public Rutina(String proposito, int numeroDias) {
        this();
        this.proposito = proposito;
        this.numeroDias = numeroDias;
    }
    
    // Método para generar ID único
    private String generarId() {
        return "RUT" + System.currentTimeMillis();
    }
    
    // Método para agregar un día de entrenamiento
    public void agregarDia(DiaEntrenamiento dia) {
        if (dias.size() < numeroDias) {
            dias.add(dia);
        }
    }
    
    // Getters y Setters
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getProposito() {
        return proposito;
    }
    
    public void setProposito(String proposito) {
        this.proposito = proposito;
    }
    
    public int getNumeroDias() {
        return numeroDias;
    }
    
    public void setNumeroDias(int numeroDias) {
        this.numeroDias = numeroDias;
    }
    
    public List<DiaEntrenamiento> getDias() {
        return dias;
    }
    
    public void setDias(List<DiaEntrenamiento> dias) {
        this.dias = dias;
    }
    
    // Método toString para representación en texto
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Rutina ID: ").append(id).append("\n");
        sb.append("Propósito: ").append(proposito).append("\n");
        sb.append("Número de días: ").append(numeroDias).append("\n\n");
        
        for (int i = 0; i < dias.size(); i++) {
            sb.append("--- DÍA ").append(i + 1).append(" ---\n");
            sb.append(dias.get(i).toString());
            sb.append("\n");
        }
        
        return sb.toString();
    }
}