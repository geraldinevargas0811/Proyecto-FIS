/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gimnasio.persistencia;

import com.gimnasio.modelo.Cliente;
import com.gimnasio.modelo.DiaEntrenamiento;
import com.gimnasio.modelo.Ejercicio;
import com.gimnasio.modelo.Rutina;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ClienteDAO {
    
    private static final String NOMBRE_ARCHIVO = "clientes.txt";
    private static final String SEPARADOR = "|";
    private static final String SEPARADOR_EJERCICIO = ";";
    
    public ClienteDAO() {
    }
    
    private String getRutaArchivo() {
    // Guardar en la carpeta del usuario (funciona en cualquier PC)
        String userHome = System.getProperty("user.home");
        File dirDatos = new File(userHome, "GimnasioWebApp/datos");
    
        if (!dirDatos.exists()) {
            dirDatos.mkdirs();
            System.out.println("📁 Directorio datos creado en: " + dirDatos.getAbsolutePath());
        }
    
        String ruta = new File(dirDatos, NOMBRE_ARCHIVO).getAbsolutePath();
        System.out.println("📍 Ruta del archivo: " + ruta);
        return ruta;
    }
    
    public boolean guardarCliente(Cliente cliente) {
        String rutaArchivo = getRutaArchivo();
        
        System.out.println("===========================================");
        System.out.println("📍 GUARDANDO CLIENTE EN: " + rutaArchivo);
        System.out.println("👤 Cliente: " + cliente.getNombre());
        System.out.println("===========================================");
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo, true))) {
            
            String linea = construirLineaCliente(cliente);
            writer.write(linea);
            writer.newLine();
            
            System.out.println("✅ Cliente guardado: " + cliente.getNombre());
            System.out.println("📍 Ubicación: " + rutaArchivo);
            
            File archivo = new File(rutaArchivo);
            System.out.println("📄 Archivo existe: " + archivo.exists());
            System.out.println("📏 Tamaño archivo: " + archivo.length() + " bytes");
            
            return true;
            
        } catch (IOException e) {
            System.err.println("❌ Error al guardar cliente: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    private String construirLineaCliente(Cliente cliente) {
        StringBuilder sb = new StringBuilder();
        
        // Datos del cliente - USAR Locale.US para forzar punto decimal
        sb.append(cliente.getId()).append(SEPARADOR);
        sb.append(cliente.getNombre()).append(SEPARADOR);
        sb.append(cliente.getEdad()).append(SEPARADOR);
        sb.append(String.format(Locale.US, "%.1f", cliente.getPeso())).append(SEPARADOR);
        sb.append(String.format(Locale.US, "%.2f", cliente.getAltura())).append(SEPARADOR);
        sb.append(String.format(Locale.US, "%.2f", cliente.getImc())).append(SEPARADOR);
        sb.append(cliente.getClasificacionIMC()).append(SEPARADOR);
        sb.append(cliente.getProposito()).append(SEPARADOR);
        sb.append(cliente.getDiasEntrenamiento()).append(SEPARADOR);
        sb.append(cliente.getFechaRegistro().toString()).append(SEPARADOR);
        
        Rutina rutina = cliente.getRutina();
        sb.append(rutina.getId()).append(SEPARADOR);
        sb.append(rutina.getProposito()).append(SEPARADOR);
        sb.append(rutina.getNumeroDias()).append(SEPARADOR);
        
        for (int i = 0; i < rutina.getDias().size(); i++) {
            DiaEntrenamiento dia = rutina.getDias().get(i);
            sb.append("[DIA:");
            sb.append(dia.getNumeroDia()).append(":");
            sb.append(dia.getNombreDia()).append(":");
            
            for (int j = 0; j < dia.getEjercicios().size(); j++) {
                Ejercicio ejercicio = dia.getEjercicios().get(j);
                sb.append(ejercicio.getNombre()).append(SEPARADOR_EJERCICIO);
                sb.append(ejercicio.getSeries()).append(SEPARADOR_EJERCICIO);
                sb.append(ejercicio.getRepeticiones()).append(SEPARADOR_EJERCICIO);
                sb.append(ejercicio.getImagenUrl());
                
                if (j < dia.getEjercicios().size() - 1) {
                    sb.append("~");
                }
            }
            
            sb.append("]");
            
            if (i < rutina.getDias().size() - 1) {
                sb.append(SEPARADOR);
            }
        }
        
        return sb.toString();
    }
    
    public List<Cliente> obtenerTodosLosClientes() {
        List<Cliente> clientes = new ArrayList<>();
        String rutaArchivo = getRutaArchivo();
        
        System.out.println("===========================================");
        System.out.println("📖 LEYENDO CLIENTES DE: " + rutaArchivo);
        
        File archivo = new File(rutaArchivo);
        
        System.out.println("📄 Archivo existe: " + archivo.exists());
        if (archivo.exists()) {
            System.out.println("📏 Tamaño archivo: " + archivo.length() + " bytes");
        }
        System.out.println("===========================================");
        
        if (!archivo.exists()) {
            System.out.println("⚠️ No hay clientes registrados aún");
            return clientes;
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            
            String linea;
            int numeroLinea = 0;
            while ((linea = reader.readLine()) != null) {
                numeroLinea++;
                System.out.println("📄 Leyendo línea " + numeroLinea + ": " + linea.substring(0, Math.min(50, linea.length())) + "...");
                
                if (!linea.trim().isEmpty()) {
                    Cliente cliente = parsearLineaCliente(linea);
                    if (cliente != null) {
                        clientes.add(cliente);
                        System.out.println("✅ Cliente parseado: " + cliente.getNombre());
                    } else {
                        System.err.println("❌ Error al parsear línea " + numeroLinea);
                    }
                }
            }
            
            System.out.println("📋 Total clientes cargados: " + clientes.size());
            
        } catch (IOException e) {
            System.err.println("❌ Error al leer clientes: " + e.getMessage());
            e.printStackTrace();
        }
        
        return clientes;
    }
    
    private Cliente parsearLineaCliente(String linea) {
        try {
            String[] partes = linea.split("\\|");
            
            if (partes.length < 13) {
                System.err.println("❌ Línea incompleta. Partes: " + partes.length);
                return null;
            }
            
            Cliente cliente = new Cliente();
            cliente.setId(partes[0]);
            cliente.setNombre(partes[1]);
            cliente.setEdad(Integer.parseInt(partes[2]));
            
            // USAR MÉTODO SEGURO PARA PARSEAR DOUBLES
            cliente.setPeso(parseDoubleSeguro(partes[3]));
            cliente.setAltura(parseDoubleSeguro(partes[4]));
            cliente.setImc(parseDoubleSeguro(partes[5]));
            
            cliente.setClasificacionIMC(partes[6]);
            cliente.setProposito(partes[7]);
            cliente.setDiasEntrenamiento(Integer.parseInt(partes[8]));
            cliente.setFechaRegistro(LocalDate.parse(partes[9]));
            
            Rutina rutina = new Rutina();
            rutina.setId(partes[10]);
            rutina.setProposito(partes[11]);
            rutina.setNumeroDias(Integer.parseInt(partes[12]));
            
            for (int i = 13; i < partes.length; i++) {
                String diaString = partes[i];
                if (diaString.startsWith("[DIA:")) {
                    DiaEntrenamiento dia = parsearDia(diaString);
                    if (dia != null) {
                        rutina.agregarDia(dia);
                    }
                }
            }
            
            cliente.setRutina(rutina);
            return cliente;
            
        } catch (Exception e) {
            System.err.println("❌ Error al parsear línea: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    private DiaEntrenamiento parsearDia(String diaString) {
        try {
            diaString = diaString.substring(5, diaString.length() - 1);
            
            String[] partesDia = diaString.split(":", 3);
            int numeroDia = Integer.parseInt(partesDia[0]);
            String nombreDia = partesDia[1];
            String ejerciciosString = partesDia[2];
            
            DiaEntrenamiento dia = new DiaEntrenamiento(numeroDia, nombreDia);
            
            String[] ejerciciosArray = ejerciciosString.split("~");
            for (String ejercicioString : ejerciciosArray) {
                String[] datosEjercicio = ejercicioString.split(";");
                
                if (datosEjercicio.length >= 4) {
                    Ejercicio ejercicio = new Ejercicio(
                        datosEjercicio[0],
                        Integer.parseInt(datosEjercicio[1]),
                        datosEjercicio[2],
                        datosEjercicio[3]
                    );
                    dia.agregarEjercicio(ejercicio);
                }
            }
            
            return dia;
            
        } catch (Exception e) {
            System.err.println("❌ Error al parsear día: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Parsea un double de forma segura, aceptando tanto punto como coma.
     */
    private double parseDoubleSeguro(String valor) {
        try {
            // Reemplazar coma por punto para normalizar
            String valorNormalizado = valor.replace(',', '.');
            return Double.parseDouble(valorNormalizado);
        } catch (NumberFormatException e) {
            System.err.println("❌ Error al parsear double: " + valor);
            return 0.0;
        }
    }
    
    public boolean limpiarArchivo() {
        try {
            String rutaArchivo = getRutaArchivo();
            File archivo = new File(rutaArchivo);
            if (archivo.exists()) {
                archivo.delete();
            }
            System.out.println("🧹 Archivo de clientes limpiado");
            return true;
        } catch (Exception e) {
            System.err.println("❌ Error al limpiar archivo: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}