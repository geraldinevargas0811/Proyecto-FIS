/* ============================================
   GIMNASIO FITPRO - VALIDACIONES Y LÓGICA
   ============================================ */

// ============================================
// VARIABLES GLOBALES Y CONSTANTES
// ============================================
const MENSAJES_ERROR = {
    nombre: {
        vacio: 'El nombre es obligatorio',
        invalido: 'El nombre solo puede contener letras y espacios',
        corto: 'El nombre debe tener al menos 3 caracteres'
    },
    edad: {
        vacio: 'La edad es obligatoria',
        invalido: 'La edad debe ser un número válido',
        rango: 'La edad debe estar entre 15 y 100 años'
    },
    peso: {
        vacio: 'El peso es obligatorio',
        invalido: 'El peso debe ser un número válido',
        rango: 'El peso debe estar entre 30 y 300 kg'
    },
    altura: {
        vacio: 'La altura es obligatoria',
        invalido: 'La altura debe ser un número válido',
        rango: 'La altura debe estar entre 1.0 y 2.5 metros'
    },
    proposito: {
        vacio: 'Debes seleccionar un propósito de entrenamiento'
    },
    diasEntrenamiento: {
        vacio: 'Los días de entrenamiento son obligatorios',
        invalido: 'Los días deben ser un número válido',
        rango: 'Los días deben estar entre 1 y 7'
    }
};

// ============================================
// INICIALIZACIÓN AL CARGAR LA PÁGINA
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ Sistema de Gimnasio FitPro cargado correctamente');
    
    // Verificar qué página estamos cargando
    const formulario = document.getElementById('formularioCliente');
    
    if (formulario) {
        inicializarFormulario();
    }
    
    // Si estamos en la página de rutina generada
    if (window.location.pathname.includes('rutina-generada')) {
        cargarDatosRutina();
    }
    
    // Si estamos en la página de datos guardados
    if (window.location.pathname.includes('ver-datos')) {
        // Los datos se cargarán desde el servlet
        console.log('📋 Página de datos guardados cargada');
    }
});

// ============================================
// INICIALIZACIÓN DEL FORMULARIO
// ============================================
function inicializarFormulario() {
    const formulario = document.getElementById('formularioCliente');
    
    if (!formulario) return;
    
    // Agregar validación en tiempo real para cada campo
    const campos = ['nombre', 'edad', 'peso', 'altura', 'proposito', 'diasEntrenamiento'];
    
    campos.forEach(campo => {
        const elemento = document.getElementById(campo);
        if (elemento) {
            // Validar al perder el foco
            elemento.addEventListener('blur', function() {
                validarCampo(campo);
            });
            
            // Limpiar error al empezar a escribir
            elemento.addEventListener('input', function() {
                limpiarError(campo);
            });
        }
    });
    
    // Manejar el envío del formulario
    formulario.addEventListener('submit', function(event) {
        event.preventDefault();
        validarYEnviarFormulario();
    });
    
    console.log('✅ Formulario inicializado con validaciones');
}

// ============================================
// VALIDACIÓN DE CAMPOS INDIVIDUALES
// ============================================
function validarCampo(nombreCampo) {
    const elemento = document.getElementById(nombreCampo);
    const valor = elemento.value.trim();
    let esValido = true;
    let mensajeError = '';
    
    switch(nombreCampo) {
        case 'nombre':
            if (valor === '') {
                esValido = false;
                mensajeError = MENSAJES_ERROR.nombre.vacio;
            } else if (valor.length < 3) {
                esValido = false;
                mensajeError = MENSAJES_ERROR.nombre.corto;
            } else if (!/^[a-záéíóúñA-ZÁÉÍÓÚÑ\s]+$/.test(valor)) {
                esValido = false;
                mensajeError = MENSAJES_ERROR.nombre.invalido;
            }
            break;
            
        case 'edad':
            if (valor === '') {
                esValido = false;
                mensajeError = MENSAJES_ERROR.edad.vacio;
            } else if (isNaN(valor) || !Number.isInteger(Number(valor))) {
                esValido = false;
                mensajeError = MENSAJES_ERROR.edad.invalido;
            } else {
                const edad = parseInt(valor);
                if (edad < 15 || edad > 100) {
                    esValido = false;
                    mensajeError = MENSAJES_ERROR.edad.rango;
                }
            }
            break;
            
        case 'peso':
            if (valor === '') {
                esValido = false;
                mensajeError = MENSAJES_ERROR.peso.vacio;
            } else if (isNaN(valor)) {
                esValido = false;
                mensajeError = MENSAJES_ERROR.peso.invalido;
            } else {
                const peso = parseFloat(valor);
                if (peso < 30 || peso > 300) {
                    esValido = false;
                    mensajeError = MENSAJES_ERROR.peso.rango;
                }
            }
            break;
            
        case 'altura':
            if (valor === '') {
                esValido = false;
                mensajeError = MENSAJES_ERROR.altura.vacio;
            } else if (isNaN(valor)) {
                esValido = false;
                mensajeError = MENSAJES_ERROR.altura.invalido;
            } else {
                const altura = parseFloat(valor);
                if (altura < 1.0 || altura > 2.5) {
                    esValido = false;
                    mensajeError = MENSAJES_ERROR.altura.rango;
                }
            }
            break;
            
        case 'proposito':
            if (valor === '') {
                esValido = false;
                mensajeError = MENSAJES_ERROR.proposito.vacio;
            }
            break;
            
        case 'diasEntrenamiento':
            if (valor === '') {
                esValido = false;
                mensajeError = MENSAJES_ERROR.diasEntrenamiento.vacio;
            } else if (isNaN(valor) || !Number.isInteger(Number(valor))) {
                esValido = false;
                mensajeError = MENSAJES_ERROR.diasEntrenamiento.invalido;
            } else {
                const dias = parseInt(valor);
                if (dias < 1 || dias > 7) {
                    esValido = false;
                    mensajeError = MENSAJES_ERROR.diasEntrenamiento.rango;
                }
            }
            break;
    }
    
    if (!esValido) {
        mostrarError(nombreCampo, mensajeError);
    } else {
        limpiarError(nombreCampo);
    }
    
    return esValido;
}

// ============================================
// MOSTRAR Y LIMPIAR ERRORES
// ============================================
function mostrarError(nombreCampo, mensaje) {
    const elemento = document.getElementById(nombreCampo);
    const errorSpan = document.getElementById('error' + capitalizar(nombreCampo));
    
    if (elemento) {
        elemento.style.borderColor = '#ff3860';
        elemento.style.backgroundColor = 'rgba(255, 56, 96, 0.1)';
    }
    
    if (errorSpan) {
        errorSpan.textContent = '⚠️ ' + mensaje;
        errorSpan.style.display = 'block';
    }
}

function limpiarError(nombreCampo) {
    const elemento = document.getElementById(nombreCampo);
    const errorSpan = document.getElementById('error' + capitalizar(nombreCampo));
    
    if (elemento) {
        elemento.style.borderColor = 'rgba(255, 107, 53, 0.3)';
        elemento.style.backgroundColor = '#1a1a2e';
    }
    
    if (errorSpan) {
        errorSpan.textContent = '';
        errorSpan.style.display = 'none';
    }
}

function limpiarTodosLosErrores() {
    const campos = ['nombre', 'edad', 'peso', 'altura', 'proposito', 'diasEntrenamiento'];
    campos.forEach(campo => limpiarError(campo));
}

// ============================================
// VALIDAR Y ENVIAR FORMULARIO
// ============================================
function validarYEnviarFormulario() {
    console.log('🔍 Validando formulario...');
    
    // Limpiar errores previos
    limpiarTodosLosErrores();
    
    // Validar todos los campos
    const campos = ['nombre', 'edad', 'peso', 'altura', 'proposito', 'diasEntrenamiento'];
    let formularioValido = true;
    
    campos.forEach(campo => {
        if (!validarCampo(campo)) {
            formularioValido = false;
        }
    });
    
    if (!formularioValido) {
        mostrarAlerta('error', 'Por favor, corrige los errores en el formulario antes de continuar.');
        return;
    }
    
    // Calcular IMC antes de enviar
    const peso = parseFloat(document.getElementById('peso').value);
    const altura = parseFloat(document.getElementById('altura').value);
    const imc = calcularIMC(peso, altura);
    const clasificacionIMC = clasificarIMC(imc);
    
    console.log(`📊 IMC calculado: ${imc.toFixed(2)} - ${clasificacionIMC}`);
    
    // Mostrar mensaje de éxito
    mostrarAlerta('success', '✅ Datos validados correctamente. Generando rutina personalizada...');
    
    // Enviar el formulario
    setTimeout(() => {
        document.getElementById('formularioCliente').submit();
    }, 1500);
}

// ============================================
// CÁLCULO DE IMC
// ============================================
function calcularIMC(peso, altura) {
    // Fórmula: IMC = peso(kg) / altura(m)²
    return peso / (altura * altura);
}

function clasificarIMC(imc) {
    if (imc < 18.5) {
        return 'Bajo peso';
    } else if (imc >= 18.5 && imc < 25) {
        return 'Normal';
    } else if (imc >= 25 && imc < 30) {
        return 'Sobrepeso';
    } else {
        return 'Obesidad';
    }
}

// ============================================
// SISTEMA DE ALERTAS
// ============================================
function mostrarAlerta(tipo, mensaje) {
    // Eliminar alertas previas
    const alertaExistente = document.querySelector('.alerta-custom');
    if (alertaExistente) {
        alertaExistente.remove();
    }
    
    // Crear nueva alerta
    const alerta = document.createElement('div');
    alerta.className = 'alerta-custom alerta-' + tipo;
    
    const icono = tipo === 'error' ? '❌' : tipo === 'success' ? '✅' : 'ℹ️';
    
    alerta.innerHTML = `
        <span class="alerta-icono">${icono}</span>
        <span class="alerta-mensaje">${mensaje}</span>
        <button class="alerta-cerrar" onclick="cerrarAlerta(this)">✕</button>
    `;
    
    // Insertar en el DOM
    document.body.appendChild(alerta);
    
    // Animar entrada
    setTimeout(() => {
        alerta.classList.add('alerta-visible');
    }, 10);
    
    // Auto-cerrar después de 5 segundos (solo si es success o info)
    if (tipo !== 'error') {
        setTimeout(() => {
            cerrarAlerta(alerta.querySelector('.alerta-cerrar'));
        }, 5000);
    }
}

function cerrarAlerta(boton) {
    const alerta = boton.parentElement;
    alerta.classList.remove('alerta-visible');
    setTimeout(() => {
        alerta.remove();
    }, 300);
}

// ============================================
// CARGAR DATOS DE RUTINA (rutina-generada.html)
// ============================================
function cargarDatosRutina() {
    console.log('📄 Cargando datos de rutina generada...');
    
    // Los datos se cargarán desde el servlet mediante JSP
    // Esta función puede usarse para funcionalidades adicionales del lado del cliente
    
    // Ejemplo: Si los datos vienen en la URL o localStorage (no recomendado por seguridad)
    // En este caso, el servlet pasará los datos mediante atributos de request
}

// ============================================
// DESCARGAR RUTINA
// ============================================
function descargarRutina() {
    console.log('📥 Descargando rutina...');
    
    // Obtener datos de la página
    const nombreCliente = document.getElementById('clienteNombre')?.textContent || 'Cliente';
    const fecha = new Date().toLocaleDateString('es-CO');
    
    // Crear contenido del archivo
    let contenido = '==============================================\n';
    contenido += '         GIMNASIO FITPRO - RUTINA PERSONALIZADA\n';
    contenido += '==============================================\n\n';
    contenido += `Cliente: ${nombreCliente}\n`;
    contenido += `Fecha de generación: ${fecha}\n\n`;
    
    // Obtener información del cliente
    contenido += '--- INFORMACIÓN DEL CLIENTE ---\n';
    contenido += `Edad: ${document.getElementById('clienteEdad')?.textContent || '-'}\n`;
    contenido += `Peso: ${document.getElementById('clientePeso')?.textContent || '-'}\n`;
    contenido += `Altura: ${document.getElementById('clienteAltura')?.textContent || '-'}\n`;
    contenido += `IMC: ${document.getElementById('clienteIMC')?.textContent || '-'}\n`;
    contenido += `Clasificación: ${document.getElementById('clienteClasificacion')?.textContent || '-'}\n`;
    contenido += `Propósito: ${document.getElementById('clienteProposito')?.textContent || '-'}\n`;
    contenido += `Días/semana: ${document.getElementById('clienteDias')?.textContent || '-'}\n\n`;
    
    // Obtener días de rutina
    const diasRutina = document.querySelectorAll('.dia-card');
    contenido += '--- RUTINA DE ENTRENAMIENTO ---\n\n';
    
    diasRutina.forEach((dia, index) => {
        const titulo = dia.querySelector('h3')?.textContent || `Día ${index + 1}`;
        contenido += `${titulo}\n`;
        contenido += '─────────────────────────────────\n';
        
        const ejercicios = dia.querySelectorAll('.ejercicio-item');
        ejercicios.forEach((ejercicio, idx) => {
            const nombre = ejercicio.querySelector('h4')?.textContent || 'Ejercicio';
            const series = ejercicio.querySelector('p')?.textContent || '';
            contenido += `${idx + 1}. ${nombre}\n`;
            contenido += `   ${series}\n\n`;
        });
        
        contenido += '\n';
    });
    
    contenido += '==============================================\n';
    contenido += '          ¡Entrena con disciplina y pasión!\n';
    contenido += '                  GIMNASIO FITPRO\n';
    contenido += '==============================================\n';
    
    // Crear archivo y descargar
    const blob = new Blob([contenido], { type: 'text/plain;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Rutina_${nombreCliente.replace(/\s+/g, '_')}_${fecha.replace(/\//g, '-')}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
    
    mostrarAlerta('success', '✅ Rutina descargada exitosamente');
}

// ============================================
// UTILIDADES
// ============================================
function capitalizar(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function formatearProposito(proposito) {
    const propositos = {
        'definicion': 'Definición Muscular',
        'volumen': 'Aumento de Volumen',
        'bajar_peso': 'Bajar de Peso',
        'mantener': 'Mantenimiento'
    };
    return propositos[proposito] || proposito;
}

function limpiarFormulario() {
    const formulario = document.getElementById('formularioCliente');
    if (formulario) {
        formulario.reset();
        limpiarTodosLosErrores();
        console.log('🧹 Formulario limpiado');
    }
}

// ============================================
// PREVENCIÓN DE ENVÍO MÚLTIPLE
// ============================================
let formularioEnviado = false;

function prevenirEnvioMultiple() {
    if (formularioEnviado) {
        return false;
    }
    formularioEnviado = true;
    return true;
}

// ============================================
// ESTILOS PARA ALERTAS (inyectados dinámicamente)
// ============================================
const estilosAlertas = `
<style>
.alerta-custom {
    position: fixed;
    top: 20px;
    right: 20px;
    min-width: 300px;
    max-width: 500px;
    padding: 20px;
    background: #16213e;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    gap: 15px;
    z-index: 10000;
    transform: translateX(150%);
    transition: transform 0.3s ease;
    border-left: 5px solid #ff6b35;
}

.alerta-custom.alerta-visible {
    transform: translateX(0);
}

.alerta-custom.alerta-error {
    border-left-color: #ff3860;
}

.alerta-custom.alerta-success {
    border-left-color: #00d9ff;
}

.alerta-custom.alerta-info {
    border-left-color: #ffd700;
}

.alerta-icono {
    font-size: 1.5rem;
}

.alerta-mensaje {
    flex: 1;
    color: #ffffff;
    font-size: 0.95rem;
    line-height: 1.5;
}

.alerta-cerrar {
    background: transparent;
    border: none;
    color: #b8b8b8;
    font-size: 1.5rem;
    cursor: pointer;
    padding: 0;
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: all 0.2s ease;
}

.alerta-cerrar:hover {
    background: rgba(255, 255, 255, 0.1);
    color: #ffffff;
}

@media (max-width: 768px) {
    .alerta-custom {
        top: 10px;
        right: 10px;
        left: 10px;
        min-width: auto;
        max-width: none;
    }
}
</style>
`;

// Inyectar estilos de alertas
if (!document.getElementById('estilos-alertas')) {
    const styleElement = document.createElement('div');
    styleElement.id = 'estilos-alertas';
    styleElement.innerHTML = estilosAlertas;
    document.head.appendChild(styleElement);
}

// ============================================
// CONSOLE LOG DECORATIVO
// ============================================
console.log('%c💪 GIMNASIO FITPRO ', 'background: #ff6b35; color: #ffffff; font-size: 20px; font-weight: bold; padding: 10px;');
console.log('%cSistema de Gestión v1.0', 'color: #00d9ff; font-size: 14px;');
console.log('%c─────────────────────────────', 'color: #b8b8b8;');

// ============================================
// EXPORTAR FUNCIONES GLOBALES
// ============================================
window.validarCampo = validarCampo;
window.descargarRutina = descargarRutina;
window.limpiarFormulario = limpiarFormulario;
window.cerrarAlerta = cerrarAlerta;
window.calcularIMC = calcularIMC;
window.clasificarIMC = clasificarIMC;